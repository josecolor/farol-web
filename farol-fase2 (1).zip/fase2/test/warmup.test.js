// Calentamiento: servicio que aparece tarde, modelo que se descarga tarde, y servicio que nunca aparece.
const http = require('http'); const assert = require('assert');
process.env.LLM_BASE_URL = 'http://127.0.0.1:19997'; process.env.LLM_MODEL = 'llama3.1:8b'; process.env.LLM_MODEL_FALLBACK = 'llama3.2:3b';
process.env.LLM_WARM_BASE_MS = '100';
const llm = require('../lib/llm');
let modelos = []; let cargados = [];
const srv = () => http.createServer((q, r) => { let b = ''; q.on('data', c => b += c); q.on('end', () => {
    if (q.url === '/api/tags') return r.end(JSON.stringify({ models: modelos.map(name => ({ name })) }));
    if (q.url === '/api/generate') { cargados.push(JSON.parse(b).model); return r.end('{"done":true}'); } r.statusCode = 404; r.end(); }); });
(async () => {
    const logs = []; const w = console.warn, l = console.log; console.warn = (...a) => logs.push(a.join(' ')); console.log = (...a) => logs.push(a.join(' '));
    // A) Servicio caído al inicio → aparece a los 400 ms con el modelo ya listo
    const p = llm.calentar({ intentos: 8, baseMs: 100 });
    await new Promise(r => setTimeout(r, 400)); modelos = ['llama3.1:8b']; const s = srv().listen(19997);
    await p; console.warn = w; console.log = l;
    assert(cargados[0] === 'llama3.1:8b', 'debe cargar el modelo principal tras reintentar'); console.log('  ✓ reintenta en segundo plano hasta que Ollama aparece');
    assert(logs.some(x => /ECONNREFUSED|rechaza la conexión/.test(x)), 'el log debe explicar la causa real'); console.log('  ✓ el log explica la causa real en vez de "fetch failed"');
    assert((await llm.estado()).precalentado === true); console.log('  ✓ estado() reporta precalentado');
    s.close();
    // B) Nunca aparece: no lanza, deja UNA línea final
    delete require.cache[require.resolve('../lib/llm')]; const llm2 = require('../lib/llm');
    const logs2 = []; console.warn = (...a) => logs2.push(a.join(' ')); console.log = (...a) => logs2.push(a.join(' '));
    await llm2.calentar({ intentos: 3, baseMs: 50 }); console.warn = w; console.log = l;
    assert(logs2.filter(x => /No se pudo precalentar/.test(x)).length === 1); console.log('  ✓ si nunca aparece: no lanza excepción, una sola advertencia final');
    // C) Nombre de servicio inexistente → diagnóstico de DNS
    process.env.LLM_BASE_URL = 'http://servicio-que-no-existe.railway.internal:11434'; delete require.cache[require.resolve('../lib/llm')];
    const llm3 = require('../lib/llm'); const e = await llm3.estado(); assert(/DNS no resuelve/.test(e.diagnostico), e.diagnostico); console.log('  ✓ nombre de servicio erróneo → "DNS no resuelve… revisa el nombre del servicio"');
    process.exit(0);
})().catch(e => { console.error('❌', e.message); process.exit(1); });
